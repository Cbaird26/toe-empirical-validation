MQGT-SCF Reissued Bundle (local, for re-upload)

Purpose:
- Provide non-expiring artifacts by letting you download once and then re-upload to GitHub Releases and/or Zenodo.

Included:
- eotwash_prl2016_digitized_contract.csv (canonical contract)
- eotwash_prl2016_digitized_contract_READY.csv (raw/sorted contract)
- eotwash_prl2016_digitized_contract_sorted.csv (lambda-sorted)
- eotwash_prl2016_digitized_contract_monotone_conservative.csv (conservative monotone envelope)
- eotwash_digitized_compare.png (raw vs monotone visual)
- eotwash_digitization_where_to_click_orange.png (click guide overlay)
- frequency_atlas.py / frequency_atlas.md (frequency ladder translation layer)
- mqgt_scf_reissued_bundle.zip (previous bundle snapshot)

Recommended permanence:
1) Create a GitHub Release in your repo(s) and attach this zip + the canonical CSV.
2) Mint a Zenodo DOI from that release for permanent citation.

Sanity / next commands (from repo root):
- ./check_digitized_csv.sh data/raw/fifth_force/eotwash_prl2016_digitized_contract.csv
- make fifth-ingest INPUT=data/raw/fifth_force/eotwash_prl2016_digitized_contract.csv
- make fifth-detectability SEED=42 NPTS=10000
